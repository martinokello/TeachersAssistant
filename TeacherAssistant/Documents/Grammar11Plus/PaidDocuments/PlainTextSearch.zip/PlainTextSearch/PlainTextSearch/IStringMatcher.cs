﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlainTextSearch
{
    interface IStringMatcher
    {
        string Text { get; set; }
        string Subtext { get; set; }
        string MatchString(string text, int currentPostion);
    }
}
