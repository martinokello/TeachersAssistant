﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlainTextSearch
{
    public static class  CaseSensitive
    {

        private static char[] smallCase =
            {
                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
                'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
            };

        private static char[] bigCase =
            {
                'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
            };

        public static bool IsEqualLetterInsensitive(this char val,char val2)
        {
            if (val == val2) return true;
            var isCaseInsensitive = false;

            for (var i = 0; i < CaseSensitive.smallCase.Length; i++)
            {
                if ((smallCase[i] == val && bigCase[i] == val2) || (smallCase[i] == val2 && bigCase[i] == val) ||
                    (smallCase[i] == val && smallCase[i] == val2) || (bigCase[i] == val && bigCase[i] == val2))
                {
                    isCaseInsensitive = true;
                    break;
                }
            }

            return isCaseInsensitive;
        }
    }
}
