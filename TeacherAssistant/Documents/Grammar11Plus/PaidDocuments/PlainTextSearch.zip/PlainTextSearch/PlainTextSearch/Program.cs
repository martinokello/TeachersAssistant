﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlainTextSearch
{
    class Program
    {
        static void Main(string[] args)
        {
            StringMatcher stringMatcher = new StringMatcher("This is the bird of the is bird is the is","bird");

            Console.Out.WriteLine(stringMatcher.MatchString("is",0));
        }
    }
}
