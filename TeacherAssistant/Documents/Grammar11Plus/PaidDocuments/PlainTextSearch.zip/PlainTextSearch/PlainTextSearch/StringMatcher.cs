﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlainTextSearch
{
    public class StringMatcher:IStringMatcher
    {
        public bool InMatch { get; set; }

        public StringBuilder ResultString = new StringBuilder();

        public string Text { get; set; }

        public string Subtext { get; set; }
        public StringMatcher(string contentString, string matchString)
        {
            Text = contentString + "\0";
            Subtext = matchString + "\0";
        }

        public string MatchString(string text, int currentPostion)
        {
            Subtext = text + "\0";
            FindOccurence(0,0,0);
            return ResultString.ToString();
        }

        public void FindOccurence(int currentPosition, int positionMatchSubtext,int foundPosition)
        {
            char currentCharacter = Text[currentPosition];

            if (InMatch && currentCharacter == '\0') ResultString.Append((foundPosition + 1).ToString());
            if (currentCharacter == '\0') return;

            if (!InMatch && currentCharacter.IsEqualLetterInsensitive(Subtext[0]))
            {
                InMatch = true;
                positionMatchSubtext = 0;
                foundPosition = currentPosition;
            }

            if (InMatch && Subtext[positionMatchSubtext] != '\0' && currentCharacter.IsEqualLetterInsensitive(Subtext[positionMatchSubtext]))
            {
                currentPosition++;
                positionMatchSubtext++;
                FindOccurence(currentPosition, positionMatchSubtext, foundPosition);
            }
            else if (InMatch && Subtext[positionMatchSubtext] == '\0')
            {
                ResultString.Append((foundPosition + 1).ToString() + ", ");
                InMatch = false;
                currentPosition++;
                positionMatchSubtext = 0;
                FindOccurence(currentPosition, positionMatchSubtext, foundPosition);
            }
            else
            {
                InMatch = false;
                currentPosition++;
                positionMatchSubtext = 0;
                FindOccurence(currentPosition, positionMatchSubtext, foundPosition);
            }

        }

    }
}
