﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.SqlClient;
namespace PowerGridApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            GridPowerHandler gridHandler = new GridPowerHandler("http://134.121.64.9:3530");
            string connectionString = "set your connection string";
            byte[] data = gridHandler.GetDataFromGrid();
            gridHandler.GridData = Encoding.UTF8.GetString(data);

            //Persist to DB:
            //Assume data is string formattable
            //Test Data to see the format:
            string stringData = Encoding.UTF8.GetString(data);

            //string data in format:
            //DateTime                            Frequency
            //01-09-2009 12:17:51        59.996
            //01-09-2009 12:17:51        59.997
            //01-09-2009 12:17:51        60.002

            MemoryStream ms = new MemoryStream(data);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                StreamReader reader = new StreamReader(ms);
                string record = "";
                while(!String.IsNullOrEmpty(record = reader.ReadLine()))
                {
                    string[] parms = record.Split(' ');
                    SqlCommand cmd = new SqlCommand(String.Format("insert into PowerGridTable ([Date],[Frequency]) values ('{0}','{1}')",parms[0],parms[1]));
                    cmd.Connection = con;
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception e)
                    {

                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }

        }
    }
}
