﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace PowerGridApplication
{
    class GridPowerHandler
    {
        private WebClient client;
        string url;

        public GridPowerHandler(string Url)
        {
            client = new WebClient();
            url = Url;
        }

        public string GridData
        {
            get;
            set;
        }

        public byte[] GetDataFromGrid()
        {
            byte[] result = null;

            try
            {
                client.Headers["useUnsafeHeaderParsing"] = "true";
                result = client.DownloadData(url);
            }
            catch (Exception e)
            {

            }
            finally
            {

            } return result;
        }
    }
}
